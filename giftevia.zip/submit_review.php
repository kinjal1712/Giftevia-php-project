<?php
session_start();
include 'includes/db.php';

if(!isset($_SESSION['user_id'])){
header("Location: login.php");
exit();
}

$user_id = $_SESSION['user_id'];
$product_id = $_POST['product_id'];
$rating = $_POST['rating'];
$review = $_POST['review'];

$stmt = $conn->prepare("
INSERT INTO reviews(product_id,user_id,rating,review)
VALUES(?,?,?,?)
");

$stmt->bind_param("iiis",$product_id,$user_id,$rating,$review);
$stmt->execute();

header("Location: product_details.php?id=".$product_id);
exit();
?>