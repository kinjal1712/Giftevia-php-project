<?php
session_start();
include 'includes/db.php';
include 'includes/header.php';

/* =========================
CHECK PRODUCT DETAIL
========================= */

$product_id = $_GET['id'] ?? null;

if($product_id){

$product = $conn->prepare("SELECT * FROM products WHERE id=?");
$product->bind_param("i",$product_id);
$product->execute();
$data = $product->get_result()->fetch_assoc();

?>

<div class="container mt-5 mb-5">

<a href="shop.php" class="btn btn-sm btn-outline-secondary mb-4">
← Back to Shop
</a>

<div class="row">

<div class="col-md-6">

<img src="assets/images/<?php echo $data['image']; ?>" 
class="img-fluid rounded">

</div>

<div class="col-md-6">

<h2><?php echo $data['name']; ?></h2>

<h4 class="mb-3">₹<?php echo $data['price']; ?></h4>

<div class="d-flex gap-2">

<form method="POST" action="add_to_cart.php">

<input type="hidden" name="product_id" value="<?php echo $data['id']; ?>">

<button class="cta-btn-sm">
Add to Cart
</button>

</form>

<a href="customize.php?id=<?php echo $data['id']; ?>" 
class="cta-btn-sm">
Customize
</a>

</div>

</div>

</div>


<!-- REVIEWS -->

<div class="mt-5">

<h4>Customer Reviews</h4>

<?php

$reviews = $conn->prepare("
SELECT reviews.*, users.name
FROM reviews
JOIN users ON reviews.user_id = users.id
WHERE product_id=?
ORDER BY created_at DESC
");

$reviews->bind_param("i",$product_id);
$reviews->execute();
$result = $reviews->get_result();

?>

<?php if($result->num_rows>0): ?>

<?php while($r=$result->fetch_assoc()): ?>

<div class="border p-3 rounded mb-3">

<strong><?php echo $r['name']; ?></strong>

<p>

<?php
for($i=1;$i<=5;$i++){
echo $i <= $r['rating'] ? "⭐" : "☆";
}
?>

</p>

<p><?php echo $r['review']; ?></p>

</div>

<?php endwhile; ?>

<?php else: ?>

<p>No reviews yet.</p>

<?php endif; ?>

</div>


<!-- REVIEW FORM -->

<?php if(isset($_SESSION['user_id'])): ?>

<div class="mt-4">

<h5>Write a Review</h5>

<form method="POST" action="submit_review.php">

<input type="hidden" name="product_id" value="<?php echo $product_id; ?>">

<select name="rating" class="form-control mb-2" required>

<option value="">Rating</option>
<option value="5">⭐⭐⭐⭐⭐</option>
<option value="4">⭐⭐⭐⭐</option>
<option value="3">⭐⭐⭐</option>
<option value="2">⭐⭐</option>
<option value="1">⭐</option>

</select>

<textarea name="review"
class="form-control mb-2"
placeholder="Write your review..."
required></textarea>

<button class="btn btn-dark">
Submit Review
</button>

</form>

</div>

<?php endif; ?>

</div>

<?php

}else{

/* =========================
SHOP PAGE
========================= */

$result = $conn->query("SELECT * FROM products");

?>

<div class="container mt-5 mb-5">

<h2 class="text-center mb-5">Our Collection</h2>

<div class="row">

<?php while($row=$result->fetch_assoc()): ?>

<div class="col-md-4 mb-4">

<div class="product-card">

<img src="assets/images/<?php echo $row['image']; ?>" 
class="product-img img-fluid">

<h4><?php echo $row['name']; ?></h4>

<p class="price">₹<?php echo $row['price']; ?></p>

<div class="d-flex justify-content-center gap-2 mt-3">

<form method="POST" action="add_to_cart.php">

<input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">

<button class="cta-btn-sm">
Add to Cart
</button>

</form>

<a href="customize.php?id=<?php echo $row['id']; ?>" 
class="cta-btn-sm">
Customize
</a>

<a href="shop.php?id=<?php echo $row['id']; ?>" 
class="cta-btn-sm">
View
</a>

</div>

</div>

</div>

<?php endwhile; ?>

</div>

</div>

<?php } ?>

<?php include 'includes/footer.php'; ?>
