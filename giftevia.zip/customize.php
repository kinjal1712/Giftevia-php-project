<?php
session_start();
include 'includes/db.php';
include 'includes/header.php';

if(!isset($_GET['id'])){
echo "Product not found";
exit();
}

$id = intval($_GET['id']);

$query = $conn->query("
SELECT p.*, pt.type_name
FROM products p
JOIN product_types pt ON p.product_type_id = pt.id
WHERE p.id=$id
");

$product = $query->fetch_assoc();

$product_type = $product['type_name'];
?>

<div class="container mt-5 mb-5">

<h2 class="text-center mb-4">Customize Product</h2>

<div style="display:flex;gap:40px;align-items:flex-start">

<!-- 3D VIEWER -->

<div id="container"
style="width:600px;height:500px;background:black;border-radius:8px">
</div>


<!-- CONTROLS -->

<div style="width:320px">

<h4 id="priceDisplay">Price: ₹<?php echo $product['price']; ?></h4>

<br>

<label>Upload Image</label>

<input type="file"
id="imageUpload"
class="form-control mb-3">

<label>Add Text</label>

<input type="text"
id="textInput"
class="form-control mb-3">

<label>Text Color</label>

<input type="color"
id="textColor"
value="#000000"
class="form-control mb-3">

<label>Product Color</label>

<input type="color"
id="productColor"
value="#ffffff"
class="form-control mb-3">


<button onclick="addText()"
class="btn btn-danger w-100 mb-2">
Add Text
</button>

<button onclick="enableImageEdit()" class="btn btn-secondary mb-2">
Edit Image
</button>

<button onclick="enableTextEdit()" class="btn btn-secondary mb-2">
Edit Text
</button>

<button onclick="clearCanvas()"
class="btn btn-outline-secondary w-100 mb-2">
Clear
</button>


<button onclick="addToCart()"
class="btn btn-success w-100">
Add To Cart
</button>

</div>

</div>

</div>


<!-- THREE JS -->


<script src="https://cdn.jsdelivr.net/npm/three@0.128.0/build/three.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>

<script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/GLTFLoader.js"></script>

<!-- VARIABLES FOR JS -->

<script>

var PRODUCT_ID = <?php echo $product['id']; ?>;

var PRODUCT_TYPE = "<?php echo $product_type; ?>";

var BASE_PRICE = <?php echo $product['price']; ?>;

var EXTRA_PRICE = 0;

</script>


<!-- CUSTOMIZER SCRIPT -->

<script src="assets/js/customizer.js"></script>


<?php include 'includes/footer.php'; ?>