<?php
include 'includes/header.php';
include 'includes/db.php';

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$cart_query = $conn->prepare("
    SELECT cart.*, products.name, products.price 
    FROM cart 
    JOIN products ON cart.product_id = products.id 
    WHERE cart.user_id = ?
");

$cart_query->bind_param("i", $user_id);
$cart_query->execute();
$result = $cart_query->get_result();

$total = 0;
?>

<div class="checkout-wrapper">

    <div class="checkout-grid">

        <!-- LEFT SIDE - FORM -->
        <div class="checkout-box">
            <h2>Checkout Details</h2>

            <form method="POST" action="place_order.php">

                <input type="text" name="fullname" placeholder="Full Name" required>

                <input type="text" name="phone" placeholder="Phone Number" pattern="[0-9]{10}" required>

                <textarea name="address" placeholder="Full Delivery Address" required></textarea>

                <select name="payment_method" required>
                    <option value="">Select Payment Method</option>
                    <option value="COD">Cash On Delivery</option>
                    <option value="UPI">UPI (Mock)</option>
                </select>

                <button type="submit" class="checkout-btn">
                    Place Order
                </button>

            </form>
        </div>

        <!-- RIGHT SIDE - ORDER REVIEW -->
        <div class="order-review">
            <h3>Order Summary</h3>

            <?php while($row = $result->fetch_assoc()): 
                $item_total = $row['price'] * $row['quantity'];
                $total += $item_total;
            ?>

            <div class="review-item">
                <span><?php echo $row['name']; ?> × <?php echo $row['quantity']; ?></span>
                <span>₹<?php echo $item_total; ?></span>
            </div>

            <?php endwhile; ?>

            <hr>

            <div class="review-total">
                <strong>Total:</strong>
                <strong>₹<?php echo $total; ?></strong>
            </div>
        </div>

    </div>

</div>

<?php include 'includes/footer.php'; ?>
<div id="upi-box" style="display:none;text-align:center;margin-top:20px">

<h4>Scan & Pay</h4>

<img src="assets/images/upi_qr.png" width="200">

<p>After payment click confirm</p>

<button type="submit" class="btn btn-success">
Confirm Payment
</button>

</div>

<script>

document.getElementById("payment_method").addEventListener("change",function(){

if(this.value=="UPI"){
document.getElementById("upi-box").style.display="block";
}else{
document.getElementById("upi-box").style.display="none";
}

});

</script>