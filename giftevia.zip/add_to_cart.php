<?php
session_start();
include 'includes/db.php';

$user_id = $_SESSION['user_id'];
$product_id = $_POST['product_id'];

$stmt = $conn->prepare("SELECT price FROM products WHERE id=?");
$stmt->bind_param("i",$product_id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

$final_price = $_POST['final_price'];
$custom_image_name = NULL;

if(!empty($_POST['design_image'])){

$data = $_POST['design_image'];

$data = explode(',', $data);
$data = base64_decode($data[1]);

$custom_image_name = "design_".time().".png";

file_put_contents("assets/uploads/".$custom_image_name,$data);

}

$stmt = $conn->prepare("
INSERT INTO cart(user_id,product_id,final_price,custom_image,quantity)
VALUES(?,?,?,?,1)
");

$stmt->bind_param("iiis",$user_id,$product_id,$final_price,$custom_image_name);
$stmt->execute();

header("Location: cart.php");
exit();
?>