<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

/* =========================
   VALIDATE INPUT
========================= */

if(
empty($_POST['fullname']) ||
empty($_POST['phone']) ||
empty($_POST['address']) ||
empty($_POST['payment_method'])
){
die("All fields are required.");
}

if(!preg_match('/^[0-9]{10}$/', $_POST['phone'])){
die("Invalid phone number.");
}

$fullname = $_POST['fullname'];
$email = $_POST['email'] ?? "";
$phone = $_POST['phone'];
$address = $_POST['address'];
$city = $_POST['city'] ?? "";
$pincode = $_POST['pincode'] ?? "";
$payment_method = $_POST['payment_method'];

/* =========================
   GET CART ITEMS
========================= */

$cart_stmt = $conn->prepare("
SELECT cart.*, products.price
FROM cart
JOIN products ON cart.product_id = products.id
WHERE cart.user_id = ?
");

$cart_stmt->bind_param("i",$user_id);
$cart_stmt->execute();
$result = $cart_stmt->get_result();

$total = 0;
$cart_items = [];

while($row = $result->fetch_assoc()){

$total += $row['price'] * $row['quantity'];
$cart_items[] = $row;

}

if(count($cart_items) == 0){
die("Cart is empty.");
}

/* =========================
   INSERT ORDER
========================= */

$order_stmt = $conn->prepare("
INSERT INTO orders
(user_id, full_name, email, phone, address, city, pincode, total_amount, payment_method, status, created_at)
VALUES (?,?,?,?,?,?,?,?,?,'Pending',NOW())
");

$order_stmt->bind_param(
"issssssds",
$user_id,
$fullname,
$email,
$phone,
$address,
$city,
$pincode,
$total,
$payment_method
);

$order_stmt->execute();

$order_id = $conn->insert_id;

/* =========================
   INSERT ORDER ITEMS
========================= */

foreach($cart_items as $item){

$item_stmt = $conn->prepare("
INSERT INTO order_items
(order_id, product_id, quantity, price, custom_image)
VALUES (?,?,?,?,?)
");

$item_stmt->bind_param(
"iiids",
$order_id,
$item['product_id'],
$item['quantity'],
$item['price'],
$item['custom_image']
);

$item_stmt->execute();

}

/* =========================
   CLEAR CART
========================= */

$clear_stmt = $conn->prepare("
DELETE FROM cart WHERE user_id=?
");

$clear_stmt->bind_param("i",$user_id);
$clear_stmt->execute();

/* =========================
   REDIRECT
========================= */

if($payment_method == "UPI"){

header("Location: upi_payment.php?order_id=".$order_id);

}else{

header("Location: order_success.php?order_id=".$order_id);

}

exit();

?>

