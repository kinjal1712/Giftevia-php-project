<?php include 'includes/header.php'; ?>

<!-- Subtle Glitter -->
<div class="particle" style="top:25%; left:20%; animation-delay:1s;"></div>
<div class="particle" style="top:50%; right:25%; animation-delay:3s;"></div>
<div class="particle" style="bottom:30%; left:40%; animation-delay:2s;"></div>

<!-- Floating Stickers -->
<div class="floating-sticker" style="top:15%; left:8%;">🎀</div>
<div class="floating-sticker" style="top:30%; right:10%;">🌸</div>
<div class="floating-sticker" style="bottom:20%; left:15%;">🎁</div>
<div class="floating-sticker" style="bottom:10%; right:18%;">🌷</div>

<!-- Hero Section -->
<section class="hero">
    <h1>Gifts That Bloom With Love</h1>
    <p>Design personalized moments wrapped in elegance & charm</p>
    <a href="shop.php" class="btn cta-btn">Start Customizing</a>
</section>

<!-- Categories -->
<section class="container section-spacing">
    <h2 class="text-center mb-5">Our Signature Creations</h2>

    <div class="row text-center">
        <div class="col-md-3 mb-4">
            <div class="category-card">
                <h4>☕ Custom Mug</h4>
                <p>Sweet names & warm memories</p>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="category-card">
                <h4>🖼 Photo Frame</h4>
                <p>Capture moments beautifully</p>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="category-card">
                <h4>👕 T-Shirt</h4>
                <p>Style with personality</p>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="category-card">
                <h4>🎁 Gift Hampers</h4>
                <p>Elegant curated surprises</p>
            </div>
        </div>
    </div>
</section>

</body>
</html>
<?php include 'includes/footer.php'; ?>