let EXTRA_PRICE = 0;
let scene,camera,renderer,controls,model;

let canvas,ctx,texture;

let img=null;
let textValue="";

let MODEL_PATH=null;

init();
animate();

function init(){

scene=new THREE.Scene();

camera=new THREE.PerspectiveCamera(45,600/500,0.1,1000);
camera.position.set(0,2,4);

renderer=new THREE.WebGLRenderer({antialias:true});
renderer.setSize(600,500);

document.getElementById("container").appendChild(renderer.domElement);

controls=new THREE.OrbitControls(camera,renderer.domElement);

/* LIGHT */

let light=new THREE.HemisphereLight(0xffffff,0x444444,1);
scene.add(light);

let dirLight=new THREE.DirectionalLight(0xffffff,1);
dirLight.position.set(5,10,7);
scene.add(dirLight);

/* MODEL */

if(PRODUCT_TYPE=="mug") MODEL_PATH="assets/models/mug.glb";
if(PRODUCT_TYPE=="tshirt") MODEL_PATH="assets/models/tshirt.glb";

/* CANVAS */

canvas=document.createElement("canvas");
canvas.width=1024;
canvas.height=512;

ctx=canvas.getContext("2d");

texture=new THREE.CanvasTexture(canvas);
texture.flipY=false;

drawCanvas();
loadModel();

}

function loadModel(){

if(PRODUCT_TYPE=="frame"){

let frame=new THREE.Mesh(
new THREE.PlaneGeometry(3,3),
new THREE.MeshStandardMaterial({map:texture})
);

scene.add(frame);
return;
}

if(PRODUCT_TYPE=="bottle"){

let bottle=new THREE.Mesh(
new THREE.CylinderGeometry(1,1,4,64),
new THREE.MeshStandardMaterial({map:texture})
);

scene.add(bottle);
return;
}

const loader=new THREE.GLTFLoader();

loader.load(MODEL_PATH,function(gltf){

model=gltf.scene;

model.scale.set(2,2,2);
model.position.set(0,-1,0);

model.traverse(function(child){

if(child.isMesh){

child.material.map=texture;
child.material.needsUpdate=true;

}

});

scene.add(model);

});

}

function animate(){

requestAnimationFrame(animate);
renderer.render(scene,camera);

}

function drawCanvas(){

ctx.fillStyle="white";
ctx.fillRect(0,0,1024,512);

if(img){
ctx.drawImage(img,420,180,200,200);
}

if(textValue){

ctx.fillStyle="black";
ctx.font="50px Arial";
ctx.textAlign="center";

ctx.fillText(textValue,512,420);

}

texture.needsUpdate=true;

}

/* IMAGE UPLOAD */

document.getElementById("imageUpload").addEventListener("change",function(e){

let reader=new FileReader();

reader.onload=function(event){

img=new Image();

img.onload=function(){
drawCanvas();
};

img.src=event.target.result;
EXTRA_PRICE += 50;
updatePrice();

};

reader.readAsDataURL(e.target.files[0]);

});

/* ADD TEXT */

function addText(){

textValue=document.getElementById("textInput").value;

drawCanvas();

}

/* ADD TO CART */

function addToCart(){

renderer.render(scene,camera);

let imgData=renderer.domElement.toDataURL("image/png");

let formData=new FormData();

formData.append("design_image",imgData);
formData.append("product_id",PRODUCT_ID);
formData.append("final_price", BASE_PRICE + EXTRA_PRICE);

fetch("add_to_cart.php",{
method:"POST",
body:formData
}).then(()=>{
window.location="cart.php";
});
}
function updatePrice(){

let total = BASE_PRICE + EXTRA_PRICE;

document.getElementById("priceDisplay").innerHTML =
"Price: ₹" + total;

}

function addText(){

textValue = document.getElementById("textInput").value;

EXTRA_PRICE += 30;
updatePrice();

drawCanvas();

}