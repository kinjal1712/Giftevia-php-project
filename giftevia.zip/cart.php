<?php
session_start();
include 'includes/db.php';
include 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("
SELECT c.*, p.name, p.image
FROM cart c
JOIN products p ON c.product_id = p.id
WHERE c.user_id=?
");

$stmt->bind_param("i",$user_id);
$stmt->execute();
$result = $stmt->get_result();

$total = 0;
?>

<div class="container mt-5 mb-5">

<h3 class="mb-4">My Cart</h3>

<table class="table align-middle">

<thead>
<tr>
<th>Product</th>
<th>Price</th>
<th>Quantity</th>
<th>Total</th>
<th>Action</th>
</tr>
</thead>

<tbody>

<?php while($row = $result->fetch_assoc()): 

$item_total = $row['final_price'] * $row['quantity'];
$total += $item_total;

?>

<tr>

<td>

<div style="display:flex;align-items:center;gap:15px;">

<?php if(!empty($row['custom_image'])){ ?>

<img src="assets/uploads/<?php echo $row['custom_image']; ?>" 
style="width:90px;border-radius:10px;box-shadow:0 4px 10px rgba(0,0,0,.15);">

<?php } else { ?>

<img src="assets/images/<?php echo $row['image']; ?>" 
style="width:90px;border-radius:10px;">

<?php } ?>

<div>

<strong><?php echo $row['name']; ?></strong>

<?php if(!empty($row['custom_image'])){ ?>
<br>
<small style="color:#C05C75;">Customized Product</small>
<?php } ?>

</div>

</div>

</td>

<td>₹<?php echo $row['final_price']; ?></td>

<td>

<form method="POST" action="update_cart.php" style="display:flex;gap:10px;align-items:center;">

<input type="hidden" name="cart_id" value="<?php echo $row['id']; ?>">

<input type="number"
name="quantity"
value="<?php echo $row['quantity']; ?>"
min="1"
style="width:70px"
class="form-control">

<button class="btn btn-sm btn-outline-secondary">
Update
</button>

</form>

</td>

<td>₹<?php echo $item_total; ?></td>

<td>

<a href="remove_cart.php?id=<?php echo $row['id']; ?>"
class="btn btn-sm btn-danger">
Remove
</a>

</td>

</tr>

<?php endwhile; ?>

</tbody>

</table>

<div class="text-end mt-4">

<h4>Total: ₹<?php echo $total; ?></h4>

<a href="checkout.php" class="btn auth-btn mt-3">
Proceed to Checkout
</a>

</div>

</div>

<?php include 'includes/footer.php'; ?>