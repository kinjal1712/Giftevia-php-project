<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$order_id = $_POST['order_id'];
$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("
    UPDATE orders 
    SET status='Cancelled'
    WHERE id=? AND user_id=? AND status='Pending'
");

$stmt->bind_param("ii", $order_id, $user_id);
$stmt->execute();

header("Location: my_orders.php");
exit();
?>