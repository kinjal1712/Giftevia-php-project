<?php
session_start();
include '../includes/db.php';

if(!isset($_SESSION['user_id']) || strtolower($_SESSION['user_role'])!='admin'){
    header("Location: ../login.php");
    exit();
}

$orders = $conn->query("
SELECT o.*, u.name
FROM orders o
JOIN users u ON o.user_id = u.id
ORDER BY o.id DESC
");
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div class="admin-content">

<h2>Manage Orders</h2>

<table class="table table-bordered mt-4">

<thead>
<tr>
<th>ID</th>
<th>Customer</th>
<th>Total</th>
<th>Status</th>
<th>Update</th>
</tr>
</thead>

<tbody>

<?php while($row = $orders->fetch_assoc()){ ?>

<tr>

<td>#<?php echo $row['id']; ?></td>

<td><?php echo $row['name']; ?></td>

<td>₹<?php echo $row['total_amount']; ?></td>

<td><?php echo $row['status']; ?></td>

<td>

<form method="POST" action="update_order.php">

<input type="hidden" name="order_id" value="<?php echo $row['id']; ?>">

<select name="status" class="form-control">

<option value="Pending" 
<?php if($row['status']=='Pending') echo 'selected'; ?>>Pending</option>

<option value="Processing"
<?php if($row['status']=='Processing') echo 'selected'; ?>>Processing</option>

<option value="Shipped"
<?php if($row['status']=='Shipped') echo 'selected'; ?>>Shipped</option>

<option value="Delivered"
<?php if($row['status']=='Delivered') echo 'selected'; ?>>Delivered</option>

<option value="Cancelled"
<?php if($row['status']=='Cancelled') echo 'selected'; ?>>Cancelled</option>

</select>

<button class="btn btn-sm btn-primary">
Update
</button>

</form>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>