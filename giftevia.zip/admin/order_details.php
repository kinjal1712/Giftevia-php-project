```php
<?php
session_start();
include '../includes/db.php';

$order_id = $_GET['id'];

$order = $conn->prepare("
SELECT orders.*, users.name
FROM orders
JOIN users ON orders.user_id = users.id
WHERE orders.id=?
");

$order->bind_param("i",$order_id);
$order->execute();
$data = $order->get_result()->fetch_assoc();

$items = $conn->prepare("
SELECT order_items.*, products.name
FROM order_items
JOIN products ON order_items.product_id = products.id
WHERE order_id=?
");

$items->bind_param("i",$order_id);
$items->execute();
$result = $items->get_result();
?>

<h2>Order Details</h2>

<p>Customer: <?php echo $data['name']; ?></p>
<p>Phone: <?php echo $data['phone']; ?></p>
<p>Address: <?php echo $data['address']; ?></p>

<table border="1" cellpadding="10">

<tr>
<th>Product</th>
<th>Qty</th>
<th>Price</th>
<th>Custom Image</th>
</tr>

<?php while($row = $result->fetch_assoc()){ ?>

<tr>

<td><?php echo $row['name']; ?></td>

<td><?php echo $row['quantity']; ?></td>

<td>₹<?php echo $row['price']; ?></td>

<td>

<?php if($row['custom_image']){ ?>

<img src="../assets/uploads/<?php echo $row['custom_image']; ?>" width="70">

<?php } ?>

</td>

</tr>

<?php } ?>

</table>

<h3>Total: ₹<?php echo $data['total_amount']; ?></h3>
```
