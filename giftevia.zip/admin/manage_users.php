<?php
session_start();
include '../includes/db.php';

if(!isset($_SESSION['user_id']) || strtolower($_SESSION['user_role'])!='admin'){
    header("Location: ../login.php");
    exit();
}

$users = $conn->query("
SELECT * FROM users
WHERE role='user'
ORDER BY id DESC
");
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div class="admin-content">

<h2>Manage Users</h2>

<table class="table table-bordered mt-4">

<thead>
<tr>
<th>ID</th>
<th>Name</th>
<th>Email</th>
</tr>
</thead>

<tbody>

<?php while($row = $users->fetch_assoc()){ ?>

<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['name']; ?></td>

<td><?php echo $row['email']; ?></td>

</tr>

<?php } ?>

</tbody>

</table>

</div>