<?php
session_start();
include '../includes/db.php';

if(!isset($_SESSION['user_id']) || strtolower($_SESSION['user_role'])!='admin'){
    header("Location: ../login.php");
    exit();
}

$product_id = $_GET['id'];

$setting = $conn->query("SELECT * FROM product_settings WHERE product_id=$product_id")->fetch_assoc();

if(isset($_POST['save'])){

$width = $_POST['width'];
$height = $_POST['height'];
$x = $_POST['x'];
$y = $_POST['y'];
$price = $_POST['price'];

if($setting){

$conn->query("
UPDATE product_settings 
SET print_width='$width',
print_height='$height',
position_x='$x',
position_y='$y',
extra_price='$price'
WHERE product_id='$product_id'
");

}else{

$conn->query("
INSERT INTO product_settings(product_id,print_width,print_height,position_x,position_y,extra_price)
VALUES('$product_id','$width','$height','$x','$y','$price')
");

}

header("Location: manage_products.php");
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div class="admin-content">

<h2>Customization Settings</h2>

<form method="POST" class="card p-4 mt-3">

<div class="row">

<div class="col-md-3">
<label>Print Width</label>
<input type="number" name="width" class="form-control"
value="<?php echo $setting['print_width'] ?? 400 ?>">
</div>

<div class="col-md-3">
<label>Print Height</label>
<input type="number" name="height" class="form-control"
value="<?php echo $setting['print_height'] ?? 400 ?>">
</div>

<div class="col-md-3">
<label>Position X</label>
<input type="number" name="x" class="form-control"
value="<?php echo $setting['position_x'] ?? 300 ?>">
</div>

<div class="col-md-3">
<label>Position Y</label>
<input type="number" name="y" class="form-control"
value="<?php echo $setting['position_y'] ?? 200 ?>">
</div>

</div>

<div class="row mt-3">

<div class="col-md-3">
<label>Extra Customization Price</label>
<input type="number" name="price" class="form-control"
value="<?php echo $setting['extra_price'] ?? 0 ?>">
</div>

</div>

<button class="btn btn-success mt-4" name="save">
Save Settings
</button>

</form>

</div>  