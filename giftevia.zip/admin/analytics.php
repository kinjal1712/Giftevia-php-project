
<?php
session_start();
include '../includes/db.php';

if(!isset($_SESSION['user_id']) || strtolower($_SESSION['user_role'])!='admin'){
header("Location: ../login.php");
exit();
}

/* PRODUCT REVENUE */

$product_data = $conn->query("
SELECT products.name,
SUM(order_items.price * order_items.quantity) as revenue
FROM order_items
JOIN products ON order_items.product_id = products.id
GROUP BY order_items.product_id
ORDER BY revenue DESC
");

$product_names=[];
$product_revenue=[];

while($row=$product_data->fetch_assoc()){
$product_names[]=$row['name'];
$product_revenue[]=$row['revenue'];
}

?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div class="admin-content">

<h2 class="mb-4">Product Revenue Analytics</h2>

<div class="analytics-grid">

<!-- PIE CHART -->

<div class="analytics-card">

<h5 class="text-center">Revenue Distribution</h5>

<div class="chart-box">

<canvas id="productChart"></canvas>

</div>

</div>

<!-- TABLE -->

<div class="analytics-card">

<h5>Product Revenue Details</h5>

<table class="analytics-table">

<thead>

<tr>

<th>Product</th>
<th>Total Revenue</th>

</tr>

</thead>

<tbody>

<?php

$product_table = $conn->query("
SELECT products.name,
SUM(order_items.price * order_items.quantity) as revenue
FROM order_items
JOIN products ON order_items.product_id = products.id
GROUP BY order_items.product_id
ORDER BY revenue DESC
");

while($row=$product_table->fetch_assoc()){
?>

<tr>

<td><?php echo $row['name']; ?></td>

<td>₹<?php echo $row['revenue']; ?></td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</div>

<style>

/* GRID */

.analytics-grid{
display:grid;
grid-template-columns:350px 1fr;
gap:30px;
}

/* CARD */

.analytics-card{
background:#fff;
padding:20px;
border-radius:10px;
box-shadow:0 2px 8px rgba(0,0,0,0.1);
}

/* CHART SIZE */

.chart-box{
width:250px;
height:250px;
margin:auto;
}

/* TABLE */

.analytics-table{
width:100%;
border-collapse:collapse;
margin-top:15px;
}

.analytics-table th{
background:#f7f7f7;
padding:12px;
border:1px solid #ddd;
text-align:left;
}

.analytics-table td{
padding:12px;
border:1px solid #ddd;
}

.analytics-table tr:nth-child(even){
background:#fafafa;
}

</style>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>

new Chart(document.getElementById('productChart'),{

type:'pie',

data:{

labels: <?php echo json_encode($product_names); ?>,

datasets:[{

data: <?php echo json_encode($product_revenue); ?>,

backgroundColor:[
'#ff6384',
'#36a2eb',
'#ffce56',
'#4bc0c0',
'#9966ff',
'#ff9f40'
]

}]

},

options:{

responsive:true,
maintainAspectRatio:false,

plugins:{
legend:{
position:'bottom'
}
}

}

});

</script>

</body>
</html>
