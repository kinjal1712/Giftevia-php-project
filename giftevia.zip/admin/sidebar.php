<div class="admin-sidebar">
    <h3>GIFTEVIA 🎀</h3>

    <a href="dashboard.php">Dashboard</a>
    <a href="manage_products.php">Manage Products</a>
    <a href="manage_orders.php">Manage Orders</a>
    <a href="manage_users.php">Manage Users</a>
    <a href="analytics.php">Sales Analytics</a>
    <a href="../index.php">Back to Website</a>


</div>