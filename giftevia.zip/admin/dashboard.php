<?php
session_start();
include '../includes/db.php';

/* ADMIN SECURITY */

if(!isset($_SESSION['user_id']) || strtolower($_SESSION['user_role']) != 'admin'){
    header("Location: ../login.php");
    exit();
}

/* DASHBOARD DATA */

$total_users = $conn->query("SELECT COUNT(*) as total FROM users WHERE role='user'")->fetch_assoc()['total'];

$total_orders = $conn->query("SELECT COUNT(*) as total FROM orders")->fetch_assoc()['total'];

$pending_orders = $conn->query("SELECT COUNT(*) as total FROM orders WHERE status='Pending'")->fetch_assoc()['total'];

$total_revenue = $conn->query("SELECT SUM(total_amount) as total FROM orders WHERE status!='Cancelled'")->fetch_assoc()['total'];

/* LATEST ORDERS */

$latest_orders = $conn->query("
SELECT o.id,u.name,o.total_amount,o.status
FROM orders o
JOIN users u ON o.user_id = u.id
ORDER BY o.id DESC
LIMIT 5
");

?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div class="admin-content">

<h2 class="mb-4">Admin Dashboard</h2>

<div class="admin-cards">

<div class="admin-card">
<h4>Total Users</h4>
<p><?php echo $total_users; ?></p>
</div>

<div class="admin-card">
<h4>Total Orders</h4>
<p><?php echo $total_orders; ?></p>
</div>

<div class="admin-card">
<h4>Pending Orders</h4>
<p><?php echo $pending_orders; ?></p>
</div>

<div class="admin-card">
<h4>Total Revenue</h4>
<p>₹<?php echo $total_revenue ? $total_revenue : 0; ?></p>
</div>

</div>

<!-- REVENUE CHART -->

<div class="admin-chart">

<h3>Revenue Overview</h3>

<canvas id="revenueChart"></canvas>

</div>

<!-- LATEST ORDERS -->

<div class="admin-table">

<h3>Latest Orders</h3>

<table class="table table-bordered">

<thead>

<tr>
<th>Order ID</th>
<th>Customer</th>
<th>Total</th>
<th>Status</th>
</tr>

</thead>

<tbody>

<?php while($row = $latest_orders->fetch_assoc()){ ?>

<tr>

<td>#<?php echo $row['id']; ?></td>

<td><?php echo $row['name']; ?></td>

<td>₹<?php echo $row['total_amount']; ?></td>

<td><?php echo $row['status']; ?></td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

<!-- CHART JS -->

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>

const ctx = document.getElementById('revenueChart');

new Chart(ctx, {

type: 'bar',

data: {

labels: ['Orders','Users','Pending Orders'],

datasets: [{

label: 'Dashboard Overview',

data: [
<?php echo $total_orders ?>,
<?php echo $total_users ?>,
<?php echo $pending_orders ?>
],

borderWidth: 1

}]

},

options: {

scales: {

y: {

beginAtZero: true

}

}

}

});

</script>

</body>
</html>