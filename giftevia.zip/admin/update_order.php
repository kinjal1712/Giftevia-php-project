<?php
session_start();
include '../includes/db.php';

if(!isset($_SESSION['user_id']) || strtolower($_SESSION['user_role'])!='admin'){
    header("Location: ../login.php");
    exit();
}

$order_id = $_POST['order_id'];
$status = $_POST['status'];

$stmt = $conn->prepare("
UPDATE orders 
SET status = ?
WHERE id = ?
");

$stmt->bind_param("si",$status,$order_id);
$stmt->execute();

header("Location: manage_orders.php");
exit();
?>