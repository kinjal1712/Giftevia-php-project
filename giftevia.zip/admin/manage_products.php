<?php
session_start();
include '../includes/db.php';

if(!isset($_SESSION['user_id']) || strtolower($_SESSION['user_role'])!='admin'){
    header("Location: ../login.php");
    exit();
}

/* ADD PRODUCT */

if(isset($_POST['add_product'])){

$name = $_POST['name'];
$price = $_POST['price'];

$image = $_FILES['image']['name'];
$tmp = $_FILES['image']['tmp_name'];

move_uploaded_file($tmp,"../assets/images/".$image);

$stmt = $conn->prepare("INSERT INTO products(name,price,image) VALUES(?,?,?)");
$stmt->bind_param("sis",$name,$price,$image);
$stmt->execute();

header("Location: manage_products.php");
exit();
}


/* UPDATE PRODUCT */

if(isset($_POST['update_product'])){

$id=$_POST['id'];
$name=$_POST['name'];
$price=$_POST['price'];

if($_FILES['image']['name']!=""){

$image=$_FILES['image']['name'];
$tmp=$_FILES['image']['tmp_name'];

move_uploaded_file($tmp,"../assets/images/".$image);

$stmt=$conn->prepare("UPDATE products SET name=?,price=?,image=? WHERE id=?");
$stmt->bind_param("sisi",$name,$price,$image,$id);

}else{

$stmt=$conn->prepare("UPDATE products SET name=?,price=? WHERE id=?");
$stmt->bind_param("sii",$name,$price,$id);

}

$stmt->execute();

header("Location: manage_products.php");
exit();
}


/* DELETE */

if(isset($_GET['delete'])){
$id=$_GET['delete'];
$conn->query("DELETE FROM products WHERE id=$id");
header("Location: manage_products.php");
exit();
}


/* EDIT FETCH */

$edit_product=null;

if(isset($_GET['edit'])){
$id=$_GET['edit'];
$edit_product=$conn->query("SELECT * FROM products WHERE id=$id")->fetch_assoc();
}


/* FETCH PRODUCTS */

$products=$conn->query("SELECT * FROM products ORDER BY id DESC");

include 'header.php';
include 'sidebar.php';
?>

<div class="admin-content">

<h2 class="page-title">Manage Products</h2>

<div class="product-layout">

<!-- LEFT SIDE CARD -->

<div class="product-card">

<?php if($edit_product){ ?>

<h3>Edit Product</h3>

<form method="POST" enctype="multipart/form-data">

<input type="hidden" name="id" value="<?php echo $edit_product['id']; ?>">

<label>Product Name</label>
<input type="text" name="name"
value="<?php echo $edit_product['name']; ?>" required>

<label>Price</label>
<input type="number" name="price"
value="<?php echo $edit_product['price']; ?>" required>

<label>Change Image</label>
<input type="file" name="image">

<button class="btn-primary" name="update_product">
Update Product
</button>

<a href="manage_products.php" class="btn-cancel">
Cancel
</a>

</form>

<?php } else { ?>

<h3>Add Product</h3>

<form method="POST" enctype="multipart/form-data">

<label>Product Name</label>
<input type="text" name="name" required>

<label>Price</label>
<input type="number" name="price" required>

<label>Product Image</label>
<input type="file" name="image" required>

<button class="btn-primary" name="add_product">
Add Product
</button>

</form>

<?php } ?>

</div>


<!-- RIGHT SIDE TABLE -->

<div class="product-table">

<table>

<thead>

<tr>
<th>ID</th>
<th>Image</th>
<th>Name</th>
<th>Price</th>
<th>Action</th>
</tr>

</thead>

<tbody>

<?php while($row=$products->fetch_assoc()){ ?>

<tr>

<td><?php echo $row['id']; ?></td>

<td>
<img src="../assets/images/<?php echo $row['image']; ?>" class="product-thumb">
</td>

<td><?php echo $row['name']; ?></td>

<td>₹<?php echo $row['price']; ?></td>

<td>

<a href="manage_products.php?edit=<?php echo $row['id']; ?>" class="btn-edit">
Edit
</a>

<a href="manage_products.php?delete=<?php echo $row['id']; ?>"
class="btn-delete"
onclick="return confirm('Delete this product?')">
Delete
</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</div>