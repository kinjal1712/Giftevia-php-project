<?php
session_start();
include 'includes/db.php';

$cart_id = intval($_POST['cart_id']);
$qty = intval($_POST['quantity']);

$stmt = $conn->prepare("
UPDATE cart SET quantity=? WHERE id=?
");

$stmt->bind_param("ii",$qty,$cart_id);
$stmt->execute();

header("Location: cart.php");
exit();
?>