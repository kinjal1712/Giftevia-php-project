
<?php
session_start();
include 'includes/db.php';
include 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("
SELECT * FROM orders 
WHERE user_id = ?
ORDER BY created_at DESC
");
$stmt->bind_param("i",$user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<div class="container mt-5 mb-5">

<h2 class="text-center mb-5">My Orders</h2>

<?php if($result->num_rows > 0): ?>

<?php while($order = $result->fetch_assoc()): ?>

<?php

$status = $order['status'];

$progress = 0;

if($status=="Pending") $progress = 25;
elseif($status=="Processing") $progress = 50;
elseif($status=="Shipped") $progress = 75;
elseif($status=="Delivered") $progress = 100;

?>

<div class="card mb-4 shadow">

<div class="card-body">

<div class="row mb-3">

<div class="col-md-3">
<strong>Order #<?php echo $order['id']; ?></strong>
</div>

<div class="col-md-3">
₹<?php echo $order['total_amount']; ?>
</div>

<div class="col-md-3">
<?php echo $order['payment_method']; ?>
</div>

<div class="col-md-3">

<span class="badge 
<?php
if($status=="Pending") echo "bg-warning";
elseif($status=="Processing") echo "bg-primary";
elseif($status=="Shipped") echo "bg-info";
elseif($status=="Delivered") echo "bg-success";
elseif($status=="Cancelled") echo "bg-danger";
?>">
<?php echo $status; ?>
</span>

</div>

</div>

<!-- PROGRESS BAR -->

<div class="progress mb-4" style="height:8px">

<div class="progress-bar bg-success" 
style="width:<?php echo $progress ?>%">
</div>

</div>

<!-- TRACKING LABELS -->

<div class="row text-center mb-4">

<div class="col">Ordered</div>
<div class="col">Processing</div>
<div class="col">Shipped</div>
<div class="col">Delivered</div>

</div>

<hr>

<!-- ORDER ITEMS -->

<?php

$items = $conn->prepare("
SELECT order_items.*, products.name
FROM order_items
JOIN products ON order_items.product_id = products.id
WHERE order_items.order_id = ?
");

$items->bind_param("i",$order['id']);
$items->execute();
$items_result = $items->get_result();

?>

<?php while($item = $items_result->fetch_assoc()): ?>

<div class="row align-items-center mb-3">

<div class="col-md-4">

<strong><?php echo $item['name']; ?></strong>

</div>

<div class="col-md-2">

Qty: <?php echo $item['quantity']; ?>

</div>

<div class="col-md-2">

₹<?php echo $item['price']; ?>

</div>

<div class="col-md-4">

<?php if(!empty($item['custom_image'])): ?>

<img src="assets/uploads/<?php echo $item['custom_image']; ?>" 
width="70" class="rounded border">

<?php endif; ?>

</div>

</div>

<?php endwhile; ?>

<!-- CANCEL BUTTON -->

<?php if($status=="Pending"): ?>

<form method="POST" action="cancel_order.php">

<input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">

<button class="btn btn-danger btn-sm">
Cancel Order
</button>

</form>

<?php endif; ?>

</div>

</div>

<?php endwhile; ?>

<?php else: ?>

<div class="text-center">
<p>No orders yet.</p>
</div>

<?php endif; ?>

</div>

<?php include 'includes/footer.php'; ?>

