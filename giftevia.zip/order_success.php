```php
<?php
session_start();
include 'includes/db.php';
include 'includes/header.php';

if(!isset($_GET['order_id'])){
header("Location: index.php");
exit();
}

$order_id = $_GET['order_id'];
?>

<div class="container mt-5 mb-5">

<div class="card shadow text-center p-5">

<h2 class="text-success mb-3">
Order Placed Successfully 🎉
</h2>

<p>Your Order ID:</p>

<h3>#<?php echo $order_id; ?></h3>

<p class="mt-3">
Estimated Delivery: 
<strong>
<?php echo date("d M Y", strtotime("+5 days")); ?>
</strong>
</p>

<div class="mt-4">

<a href="my_orders.php" class="btn btn-primary">
Track Order
</a>

<a href="invoice.php?order_id=<?php echo $order_id; ?>" 
class="btn btn-outline-dark">
Download Invoice
</a>

</div>

</div>

</div>

<?php include 'includes/footer.php'; ?>
```
