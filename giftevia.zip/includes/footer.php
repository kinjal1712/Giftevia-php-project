<footer class="footer-section">
    <div class="container text-center">
        <h5>GIFTEVIA 🎀</h5>
        <p>Crafting Personalized Memories With Love</p>

        <p class="copyright">
            © <?php echo date("Y"); ?> GIFTEVIA. All Rights Reserved.
        </p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>