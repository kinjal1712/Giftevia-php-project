<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include_once __DIR__ . '/db.php'; // make sure db connection exists

$cart_count = 0;

if(isset($_SESSION['user_id'])){

$uid = $_SESSION['user_id'];

$q = $conn->prepare("SELECT COUNT(*) as total FROM cart WHERE user_id=?");
$q->bind_param("i",$uid);
$q->execute();
$r = $q->get_result()->fetch_assoc();

$cart_count = $r['total'];
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>GIFTEVIA - Customize Your Happiness</title>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;600;700&family=Montserrat:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css?v=5">
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-light fixed-top">
    <div class="container">

        <!-- Logo -->
        <a class="navbar-brand logo-main" href="index.php">
            GIFTEVIA 🎀
        </a>

        <!-- Toggle -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Menu -->
        <div class="collapse navbar-collapse justify-content-end" id="navbarContent">
            <ul class="navbar-nav mb-2 mb-lg-0">

                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="shop.php">Shop</a>
                </li>

                <ul class="navbar-nav ms-auto align-items-center">

                <li class="nav-item">
                    <a class="nav-link position-relative" href="cart.php">
                        Cart
                        <?php if ($cart_count > 0): ?>
                            <span class="badge bg-danger position-absolute top-0 start-100 translate-middle">
                                <?php echo $cart_count; ?>
                            </span>
                        <?php endif; ?>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="my_orders.php">
                        My Orders
                    </a>
                </li>
        
                <?php if(isset($_SESSION['user_id'])) { ?>

                    <li class="nav-item">
                        <span class="nav-link">
                            <?php echo $_SESSION['user_email']; ?>
                        </span>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>

                <?php } else { ?>

                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>

                <?php } ?>

            </ul>
        </div>
    </div>
    <?php
$cart_count = 0;
if(isset($_SESSION['user_id'])){
    $uid = $_SESSION['user_id'];
    $count_stmt = $conn->prepare("SELECT SUM(quantity) as total FROM cart WHERE user_id=?");
    $count_stmt->bind_param("i", $uid);
    $count_stmt->execute();
    $count_result = $count_stmt->get_result()->fetch_assoc();
    $cart_count = $count_result['total'] ?? 0;
}
?>
</nav>

<div style="margin-top:120px;"></div>